package com.codingblocks.iosd;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;



public class login_page extends AppCompatActivity  implements View.OnClickListener{
  private   EditText maillogin,passlogin;
    private   CheckBox checkBox;
    private  Button login,signup;
    private TextView forgetpass;
    private FirebaseAuth mauth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login_page);
        maillogin=findViewById(R.id.loginemail);
        passlogin=findViewById(R.id.loginpass);
        checkBox=findViewById(R.id.logincheck);
        login=findViewById(R.id.loginbutton);
        signup=findViewById(R.id.signupbutton);
        forgetpass=findViewById(R.id.loginforgot);
        login.setOnClickListener(this);
        signup.setOnClickListener(this);
        forgetpass.setOnClickListener(this);



    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user=mauth.getCurrentUser();
        if(user!=null)
        {
            Sendusertomainactivity();

        }
    }
 private void  Allowusertologin()
 {
     String mail=maillogin.getText().toString();
     String pass=maillogin.getText().toString();
 if(TextUtils.isEmpty(mail))
 {
     Toast.makeText(this,"Please write your email",Toast.LENGTH_SHORT).show();
 }
else if(TextUtils.isEmpty(pass))
 {
     Toast.makeText(this,"Please enter your password",Toast.LENGTH_SHORT).show();
 }



 }
    @Override

 public void onClick(View v)
 {

    switch (v.getId())
    {
        case(R.id.loginbutton):











    }




 }

private  void Sendusertomainactivity()
{
    Intent main=new Intent(this,MainActivity.class);
    main.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK);
    startActivity(main);




}
}
