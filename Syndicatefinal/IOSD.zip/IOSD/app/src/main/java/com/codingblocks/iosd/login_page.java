package com.codingblocks.iosd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.ActionBar;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;



public class login_page extends AppCompatActivity  implements View.OnClickListener {
    private EditText maillogin, passlogin;
    private CheckBox checkBox;
    private Button login, signup;
    private TextView forgetpass;
    private FirebaseAuth mauth;
    private ProgressBar progressBar;
    private  Fragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);

        getSupportActionBar().hide();


        setContentView(R.layout.activity_login_page);
        maillogin = findViewById(R.id.loginemail);
        passlogin = findViewById(R.id.loginpass);
        checkBox = findViewById(R.id.logincheck);
        login = findViewById(R.id.loginbutton);
        signup = findViewById(R.id.signupbutton);
        forgetpass = findViewById(R.id.loginforgot);
        progressBar = findViewById(R.id.progressBar_cyclic);


        login.setOnClickListener(this);
     signup.setOnClickListener(this);
//        forgetpass.setOnClickListener(this);
        mauth = FirebaseAuth.getInstance();


    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseUser user = mauth.getCurrentUser();
        if (user != null) {
            Sendusertomainactivity();

        }
    }

    private void Allowusertologin() {
        String mail = maillogin.getText().toString();
        String pass = passlogin.getText().toString();
        if (TextUtils.isEmpty(mail)) {
            Toast.makeText(this, "Please write your email", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(pass)) {
            Toast.makeText(this, "Please enter your password", Toast.LENGTH_SHORT).show();
        } else {


            mauth.signInWithEmailAndPassword(mail, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        Sendusertomainactivity();

                        Toast.makeText(login_page.this, "you are logged in sucessfully", Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.INVISIBLE);


                    } else {
                        String message = task.getException().getMessage();
                        Toast.makeText(login_page.this, "Error Occured:" + message, Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.INVISIBLE);


                    }

                }
            });


        }


    }

    public void onBackPressed() {
        super.onBackPressed();
        progressBar.setVisibility(View.GONE);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
    }

    @Override
    public void onClick(View v) {
        progressBar.setVisibility(v.VISIBLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);


        switch (v.getId()) {
            case (R.id.loginbutton): {
                Allowusertologin();
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);

            }
            case(R.id.signupbutton):
            {
                FragmentManager manager = getFragmentManager();
                FragmentTransaction transaction = manager.beginTransaction();
                fragment=new signupfragment();
                transaction.add(R.id.container,fragment,"my signup fragment");
                transaction.addToBackStack(null);
                transaction.commit();
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            }


        }
    }
        private void Sendusertomainactivity()
        {
            Intent main = new Intent(this, MainActivity.class);
            main.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(main);


        }

    }


